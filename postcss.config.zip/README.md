# SRCS Frontend — Student Result Compilation and Scaling System

React + TypeScript frontend for the SRCS PRD, wired to the NestJS/Prisma
backend over **axios**.

- **React 19 + TypeScript** (Vite 8)
- **React Router 7** with role-based route guards
- **Tailwind CSS v4** (custom "ledger" tokens in `src/index.css`)
- **SWR** for data fetching / caching (loading + error per request)
- **Zustand** for auth session + UI/toast state
- **Axios** HTTP client (`src/lib/apiClient.ts`) with a bearer-token
  interceptor and centralized 401 handling

## How the API integration is structured

Every screen reads data through a hook (`src/hooks/*`) that calls a function in
`src/api/*`, which calls the shared axios client. The backend is the source of
truth for routes and response shapes; each `src/api/*` module **adapts** the
backend payloads into the view types in `src/types`. Enum/shape translation
lives in `src/api/_mappers.ts`. Pages and hooks were not changed — only the API
layer — so loading and error states flow through unchanged.

| Screen | Backend route(s) used |
|--------|-----------------------|
| Login | `POST /auth/login` |
| Admin · Students | `GET /students`, `GET /departments` |
| Admin · Courses | `GET /courses`, `GET /departments`, `GET /students` |
| Admin · Lecturers | `GET /users`, `GET /courses` |
| Admin · Grading scale | `GET`/`POST /grading-scales` |
| Upload scores | `POST /courses/:id/scores/upload` (multipart) |
| Compile & match | `POST /courses/:id/compile` |
| Score scaling | `POST /courses/:id/scaling/preview` · `/apply` |
| Result summary | `GET /courses/:id/summary` |
| Export | `GET /courses/:id/export/xlsx` · `/pdf` (file download) |
| Audit trail | `GET /audit` |

## Running locally

1. **Start the backend** (the `srcs-server` project) on `http://localhost:3000`:
   ```bash
   cd srcs-server
   npm install
   cp .env.example .env         # set DATABASE_URL + JWT_SECRET
   npm run prisma:generate && npm run prisma:migrate
   npm run db:seed              # creates admin@srcs.local / admin12345
   npm run start:dev
   ```

2. **Start this frontend**:
   ```bash
   npm install
   cp .env.example .env          # optional; defaults already target :3000
   npm run dev
   ```
   The Vite dev server proxies `/api` → `http://localhost:3000`, so no CORS
   setup is needed. To point at a different backend, set `VITE_API_PROXY_TARGET`
   (dev proxy) or `VITE_API_BASE_URL` (absolute URL).

3. Open the printed URL and sign in with the seeded admin
   (`admin@srcs.local` / `admin12345`).

### Seeing the full lecturer flow

The default seed creates an admin, a department and a grading scale. To exercise
upload → compile → scale → export you need a **course with students and scores**,
owned by the account you use. The quickest path:

- Sign in as the admin and create a department, a course, and a few students —
  or seed them directly in the backend.
- To use the **lecturer** screens (upload/compile/scaling/export), sign in as a
  lecturer who owns the course. Register one via `POST /api/auth/register`,
  approve it (`PATCH /api/users/:id/approval`), and set the course's
  `lecturerId`. (Admins can view all data but the lecturer-only routes are
  guarded to the lecturer role in the UI.)

### Run without a backend

Set `VITE_USE_MOCKS=true` in `.env` to use the in-browser mock adapter
(`src/mocks/*`) instead of a live server.

## Notes on backend gaps (graceful degradation)

A few UI features have no v1 backend endpoint; the API layer degrades cleanly
rather than erroring:

- **Unmatched exceptions** are derived from compiled rows flagged `incomplete`.
  Resolving an exception is acknowledged client-side — re-upload a corrected
  table to actually change the data.
- **Export history** is not persisted; exporting downloads the real file and the
  history panel stays empty.
- **Submit for HOD moderation** resolves locally (no route yet).
- The **audit trail** is admin-only on the backend; for a lecturer it returns an
  empty list instead of a 403 error.

## Scripts

```bash
npm run dev       # Vite dev server (proxies /api to the backend)
npm run build     # tsc -b && vite build
npm run preview   # preview the production build
npm run lint      # oxlint
```
